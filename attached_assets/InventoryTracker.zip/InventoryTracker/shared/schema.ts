import { pgTable, text, serial, integer, numeric, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Categories table
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  name: true,
  description: true,
});

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

// Items table
export const items = pgTable("items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  sku: text("sku").notNull().unique(),
  description: text("description"),
  categoryId: integer("category_id").notNull(),
  price: numeric("price").notNull(),
  quantity: integer("quantity").default(0).notNull(),
  lowStockThreshold: integer("low_stock_threshold").default(10),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const insertItemSchema = createInsertSchema(items).pick({
  name: true,
  sku: true,
  description: true,
  categoryId: true,
  price: true,
  quantity: true,
  lowStockThreshold: true,
});

export type InsertItem = z.infer<typeof insertItemSchema>;
export type Item = typeof items.$inferSelect;

// Transactions table
export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  itemId: integer("item_id").notNull(),
  quantity: integer("quantity").notNull(),
  type: text("type").notNull(), // 'in' or 'out'
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTransactionSchema = createInsertSchema(transactions).pick({
  itemId: true,
  quantity: true,
  type: true,
  notes: true,
});

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

// Dashboard Stats type
export type DashboardStats = {
  totalItems: number;
  itemsGrowth: string;
  lowStockItems: number;
  lowStockGrowth: string;
  categories: number;
  categoriesGrowth: string;
  totalValue: string;
  valueGrowth: string;
};

// Item with category information
export type ItemWithCategory = Item & {
  category: Category;
};

// Category with item count
export type CategoryWithCount = Category & {
  itemCount: number;
  percentage: number;
};
