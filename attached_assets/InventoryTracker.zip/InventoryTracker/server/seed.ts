import { db } from "./db";
import { categories, items, transactions } from "@shared/schema";

async function seed() {
  console.log("Seeding database...");

  // Check if we already have data
  const existingCategories = await db.select().from(categories);
  if (existingCategories.length > 0) {
    console.log("Database already has data, skipping seeding.");
    return;
  }

  // Seed categories
  console.log("Seeding categories...");
  const insertedCategories = await db.insert(categories).values([
    { name: "Electronics", description: "Electronic devices and gadgets" },
    { name: "Office Supplies", description: "Office stationery and supplies" },
    { name: "Furniture", description: "Office and home furniture" },
    { name: "Clothing", description: "Apparel and accessories" }
  ]).returning();

  console.log(`Inserted ${insertedCategories.length} categories.`);

  // Get category IDs for reference
  const electronicsId = insertedCategories.find(c => c.name === "Electronics")?.id || 1;
  const officeSuppliesId = insertedCategories.find(c => c.name === "Office Supplies")?.id || 2;
  const furnitureId = insertedCategories.find(c => c.name === "Furniture")?.id || 3;
  const clothingId = insertedCategories.find(c => c.name === "Clothing")?.id || 4;

  // Seed items
  console.log("Seeding items...");
  const insertedItems = await db.insert(items).values([
    {
      name: "Wireless Keyboard",
      sku: "SKU-1234-AB",
      description: "Ergonomic wireless keyboard with long battery life",
      categoryId: electronicsId,
      price: "49.99",
      quantity: 25,
      lowStockThreshold: 10,
      lastUpdated: new Date()
    },
    {
      name: "LED Monitor",
      sku: "SKU-5678-CD",
      description: "24-inch LED monitor with HD resolution",
      categoryId: electronicsId,
      price: "199.99",
      quantity: 15,
      lowStockThreshold: 5,
      lastUpdated: new Date()
    },
    {
      name: "Office Chair",
      sku: "SKU-9012-EF",
      description: "Comfortable office chair with adjustable height",
      categoryId: furnitureId,
      price: "149.99",
      quantity: 8,
      lowStockThreshold: 3,
      lastUpdated: new Date()
    },
    {
      name: "Company T-Shirt",
      sku: "SKU-3456-GH",
      description: "Company branded t-shirt, cotton",
      categoryId: clothingId,
      price: "19.99",
      quantity: 50,
      lowStockThreshold: 15,
      lastUpdated: new Date()
    },
    {
      name: "Sticky Notes",
      sku: "SKU-7890-IJ",
      description: "Colorful sticky notes pack of 6",
      categoryId: officeSuppliesId,
      price: "9.99",
      quantity: 100,
      lowStockThreshold: 30,
      lastUpdated: new Date()
    }
  ]).returning();

  console.log(`Inserted ${insertedItems.length} items.`);

  // Seed transactions
  console.log("Seeding transactions...");
  const wirelessKeyboardId = insertedItems.find(i => i.name === "Wireless Keyboard")?.id || 1;
  const ledMonitorId = insertedItems.find(i => i.name === "LED Monitor")?.id || 2;
  
  const insertedTransactions = await db.insert(transactions).values([
    {
      itemId: wirelessKeyboardId,
      quantity: 10,
      type: "stock_in",
      notes: "Initial stock",
      createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) // 7 days ago
    },
    {
      itemId: wirelessKeyboardId,
      quantity: 2,
      type: "stock_out",
      notes: "Office use",
      createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000) // 3 days ago
    },
    {
      itemId: ledMonitorId,
      quantity: 5,
      type: "stock_in",
      notes: "Resupply",
      createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000) // 5 days ago
    }
  ]).returning();

  console.log(`Inserted ${insertedTransactions.length} transactions.`);
  console.log("Database seeding completed.");
}

// Execute the seed function
seed()
  .then(() => {
    console.log("Seed script finished.");
  })
  .catch(error => {
    console.error("Error during seeding:", error);
    process.exit(1);
  });

export default seed;