import { 
  users, type User, type InsertUser, 
  categories, type Category, type InsertCategory,
  items, type Item, type InsertItem,
  transactions, type Transaction, type InsertTransaction,
  type DashboardStats, type ItemWithCategory, type CategoryWithCount
} from "@shared/schema";

// Interface for all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category operations
  getAllCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryByName(name: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;
  getCategoriesWithCount(): Promise<CategoryWithCount[]>;
  
  // Item operations
  getAllItems(): Promise<Item[]>;
  getItemsWithCategories(): Promise<ItemWithCategory[]>;
  getItem(id: number): Promise<Item | undefined>;
  getItemBySku(sku: string): Promise<Item | undefined>;
  createItem(item: InsertItem): Promise<Item>;
  updateItem(id: number, item: Partial<InsertItem>): Promise<Item | undefined>;
  deleteItem(id: number): Promise<boolean>;
  getLowStockItems(): Promise<ItemWithCategory[]>;
  searchItems(query: string): Promise<ItemWithCategory[]>;
  
  // Transaction operations
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  getTransactionsByItemId(itemId: number): Promise<Transaction[]>;
  
  // Dashboard operations
  getDashboardStats(): Promise<DashboardStats>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private items: Map<number, Item>;
  private transactions: Map<number, Transaction>;
  
  currentUserId: number;
  currentCategoryId: number;
  currentItemId: number;
  currentTransactionId: number;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.items = new Map();
    this.transactions = new Map();
    
    this.currentUserId = 1;
    this.currentCategoryId = 1;
    this.currentItemId = 1;
    this.currentTransactionId = 1;
    
    // Initialize with default categories
    this.initializeDefaultData();
  }
  
  private initializeDefaultData() {
    // Create default categories
    const defaultCategories: InsertCategory[] = [
      { name: "Electronics", description: "Electronic devices and accessories" },
      { name: "Furniture", description: "Office and home furniture" },
      { name: "Office Supplies", description: "Stationery and office supplies" },
      { name: "Accessories", description: "Various accessories" }
    ];
    
    defaultCategories.forEach(category => this.createCategory(category));
    
    // Create sample items
    const sampleItems: InsertItem[] = [
      {
        name: "Wireless Keyboard",
        sku: "SKU-1234-AB",
        description: "Ergonomic wireless keyboard",
        categoryId: 1,
        price: "45.99",
        quantity: 28,
        lowStockThreshold: 10
      },
      {
        name: "Ergonomic Chair",
        sku: "SKU-5678-CD",
        description: "Adjustable office chair",
        categoryId: 2,
        price: "189.99",
        quantity: 5,
        lowStockThreshold: 8
      },
      {
        name: "HD Monitor",
        sku: "SKU-9012-EF",
        description: "24-inch HD monitor",
        categoryId: 1,
        price: "249.99",
        quantity: 2,
        lowStockThreshold: 5
      },
      {
        name: "USB-C Cable Pack",
        sku: "SKU-3456-GH",
        description: "Pack of 3 USB-C cables",
        categoryId: 1,
        price: "19.99",
        quantity: 78,
        lowStockThreshold: 20
      },
      {
        name: "Desk Lamp",
        sku: "SKU-7890-IJ",
        description: "LED desk lamp with adjustable brightness",
        categoryId: 2,
        price: "32.50",
        quantity: 42,
        lowStockThreshold: 15
      }
    ];
    
    sampleItems.forEach(item => this.createItem(item));
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Category operations
  async getAllCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }
  
  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }
  
  async getCategoryByName(name: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.name === name,
    );
  }
  
  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.currentCategoryId++;
    const category: Category = { 
      id,
      name: insertCategory.name,
      description: insertCategory.description ?? null 
    };
    this.categories.set(id, category);
    return category;
  }
  
  async updateCategory(id: number, categoryUpdate: Partial<InsertCategory>): Promise<Category | undefined> {
    const existingCategory = this.categories.get(id);
    if (!existingCategory) return undefined;
    
    const updatedCategory: Category = {
      ...existingCategory,
      name: categoryUpdate.name ?? existingCategory.name,
      description: categoryUpdate.description ?? existingCategory.description
    };
    
    this.categories.set(id, updatedCategory);
    return updatedCategory;
  }
  
  async deleteCategory(id: number): Promise<boolean> {
    // Check if category is in use
    const itemsInCategory = Array.from(this.items.values()).filter(
      (item) => item.categoryId === id
    );
    
    if (itemsInCategory.length > 0) {
      return false;
    }
    
    return this.categories.delete(id);
  }
  
  async getCategoriesWithCount(): Promise<CategoryWithCount[]> {
    const categories = await this.getAllCategories();
    const items = Array.from(this.items.values());
    const totalItems = items.length;
    
    return categories.map(category => {
      const itemCount = items.filter(item => item.categoryId === category.id).length;
      const percentage = totalItems > 0 ? Math.round((itemCount / totalItems) * 100) : 0;
      
      return {
        ...category,
        itemCount,
        percentage
      };
    }).sort((a, b) => b.percentage - a.percentage);
  }
  
  // Item operations
  async getAllItems(): Promise<Item[]> {
    return Array.from(this.items.values());
  }
  
  async getItemsWithCategories(): Promise<ItemWithCategory[]> {
    const items = await this.getAllItems();
    const itemsWithCategories: ItemWithCategory[] = [];
    
    for (const item of items) {
      const category = await this.getCategory(item.categoryId);
      if (category) {
        itemsWithCategories.push({
          ...item,
          category
        });
      }
    }
    
    return itemsWithCategories;
  }
  
  async getItem(id: number): Promise<Item | undefined> {
    return this.items.get(id);
  }
  
  async getItemBySku(sku: string): Promise<Item | undefined> {
    return Array.from(this.items.values()).find(
      (item) => item.sku === sku,
    );
  }
  
  async createItem(insertItem: InsertItem): Promise<Item> {
    const id = this.currentItemId++;
    const now = new Date();
    const item: Item = {
      id,
      name: insertItem.name,
      sku: insertItem.sku,
      description: insertItem.description ?? null,
      categoryId: insertItem.categoryId,
      price: insertItem.price,
      quantity: insertItem.quantity ?? 0,
      lowStockThreshold: insertItem.lowStockThreshold ?? null,
      lastUpdated: now
    };
    
    this.items.set(id, item);
    
    // Create transaction record for the new stock
    if (Number(item.quantity) > 0) {
      await this.createTransaction({
        itemId: id,
        quantity: Number(item.quantity),
        type: 'in',
        notes: 'Initial stock'
      });
    }
    
    return item;
  }
  
  async updateItem(id: number, itemUpdate: Partial<InsertItem>): Promise<Item | undefined> {
    const existingItem = this.items.get(id);
    if (!existingItem) return undefined;
    
    const now = new Date();
    
    // Calculate quantity change for transaction record
    if (itemUpdate.quantity !== undefined && Number(itemUpdate.quantity) !== Number(existingItem.quantity)) {
      const quantityDifference = Number(itemUpdate.quantity) - Number(existingItem.quantity);
      
      if (quantityDifference !== 0) {
        await this.createTransaction({
          itemId: id,
          quantity: Math.abs(quantityDifference),
          type: quantityDifference > 0 ? 'in' : 'out',
          notes: 'Stock update'
        });
      }
    }
    
    const updatedItem: Item = {
      id: existingItem.id,
      name: itemUpdate.name ?? existingItem.name,
      sku: itemUpdate.sku ?? existingItem.sku,
      description: itemUpdate.description ?? existingItem.description,
      categoryId: itemUpdate.categoryId ?? existingItem.categoryId,
      price: itemUpdate.price ?? existingItem.price,
      quantity: itemUpdate.quantity ?? existingItem.quantity,
      lowStockThreshold: itemUpdate.lowStockThreshold ?? existingItem.lowStockThreshold,
      lastUpdated: now
    };
    
    this.items.set(id, updatedItem);
    return updatedItem;
  }
  
  async deleteItem(id: number): Promise<boolean> {
    return this.items.delete(id);
  }
  
  async getLowStockItems(): Promise<ItemWithCategory[]> {
    const items = Array.from(this.items.values()).filter(
      (item) => Number(item.quantity) <= Number(item.lowStockThreshold)
    );
    
    const result: ItemWithCategory[] = [];
    
    for (const item of items) {
      const category = await this.getCategory(item.categoryId);
      if (category) {
        result.push({
          ...item,
          category
        });
      }
    }
    
    return result.sort((a, b) => Number(a.quantity) - Number(b.quantity));
  }
  
  async searchItems(query: string): Promise<ItemWithCategory[]> {
    if (!query) {
      return this.getItemsWithCategories();
    }
    
    const lowerQuery = query.toLowerCase();
    const filteredItems = Array.from(this.items.values()).filter(
      (item) => 
        item.name.toLowerCase().includes(lowerQuery) ||
        item.sku.toLowerCase().includes(lowerQuery) ||
        (item.description && item.description.toLowerCase().includes(lowerQuery))
    );
    
    const result: ItemWithCategory[] = [];
    
    for (const item of filteredItems) {
      const category = await this.getCategory(item.categoryId);
      if (category) {
        result.push({
          ...item,
          category
        });
      }
    }
    
    return result;
  }
  
  // Transaction operations
  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const id = this.currentTransactionId++;
    const now = new Date();
    
    const transaction: Transaction = {
      id,
      type: insertTransaction.type,
      quantity: insertTransaction.quantity,
      itemId: insertTransaction.itemId,
      notes: insertTransaction.notes ?? null,
      createdAt: now
    };
    
    this.transactions.set(id, transaction);
    return transaction;
  }
  
  async getTransactionsByItemId(itemId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter((transaction) => transaction.itemId === itemId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  // Dashboard operations
  async getDashboardStats(): Promise<DashboardStats> {
    const items = await this.getAllItems();
    const categories = await this.getAllCategories();
    const lowStockItems = items.filter(
      (item) => Number(item.quantity) <= Number(item.lowStockThreshold)
    );
    
    // Calculate total value
    const totalValue = items.reduce(
      (sum, item) => sum + Number(item.price) * Number(item.quantity),
      0
    );
    
    // Format value as currency
    const formattedTotalValue = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(totalValue);
    
    return {
      totalItems: items.length,
      itemsGrowth: "12% from last month",
      lowStockItems: lowStockItems.length,
      lowStockGrowth: "5% from last week",
      categories: categories.length,
      categoriesGrowth: "3 new this month",
      totalValue: formattedTotalValue,
      valueGrowth: "8% from last month"
    };
  }
}

// Create and export a singleton instance
import { db } from "./db";
import { eq, and, like, desc, asc, sql } from "drizzle-orm";

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async getCategory(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category || undefined;
  }

  async getCategoryByName(name: string): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.name, name));
    return category || undefined;
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const [category] = await db
      .insert(categories)
      .values(insertCategory)
      .returning();
    return category;
  }

  async updateCategory(id: number, categoryUpdate: Partial<InsertCategory>): Promise<Category | undefined> {
    const [updatedCategory] = await db
      .update(categories)
      .set(categoryUpdate)
      .where(eq(categories.id, id))
      .returning();
    return updatedCategory || undefined;
  }

  async deleteCategory(id: number): Promise<boolean> {
    const result = await db
      .delete(categories)
      .where(eq(categories.id, id))
      .returning({ id: categories.id });
    return result.length > 0;
  }

  async getCategoriesWithCount(): Promise<CategoryWithCount[]> {
    const result = await db.execute(sql`
      SELECT 
        c.id, c.name, c.description,
        COUNT(i.id) as "itemCount",
        ROUND((COUNT(i.id) * 100.0 / NULLIF((SELECT COUNT(*) FROM ${items}), 0)), 1) as "percentage"
      FROM ${categories} c
      LEFT JOIN ${items} i ON c.id = i.category_id
      GROUP BY c.id
    `);
    
    return result.rows.map(row => ({
      id: Number(row.id),
      name: String(row.name),
      description: row.description === null ? null : String(row.description),
      itemCount: Number(row.itemCount) || 0,
      percentage: Number(row.percentage) || 0
    }));
  }

  async getAllItems(): Promise<Item[]> {
    return await db.select().from(items);
  }

  async getItemsWithCategories(): Promise<ItemWithCategory[]> {
    const result = await db.execute(sql`
      SELECT 
        i.id, i.name, i.sku, i.description, i.price, i.quantity, 
        i.low_stock_threshold as "lowStockThreshold", 
        i.category_id as "categoryId", 
        i.last_updated as "lastUpdated",
        c.id as "cId", c.name as "cName", c.description as "cDescription"
      FROM ${items} i
      JOIN ${categories} c ON i.category_id = c.id
    `);

    return result.rows.map(row => ({
      id: Number(row.id),
      name: String(row.name),
      sku: String(row.sku),
      description: row.description === null ? null : String(row.description),
      price: String(row.price),
      quantity: Number(row.quantity),
      lowStockThreshold: row.lowStockThreshold === null ? null : Number(row.lowStockThreshold),
      categoryId: Number(row.categoryId),
      lastUpdated: new Date(String(row.lastUpdated)),
      category: {
        id: Number(row.cId),
        name: String(row.cName),
        description: row.cDescription === null ? null : String(row.cDescription)
      }
    }));
  }

  async getItem(id: number): Promise<Item | undefined> {
    const [item] = await db.select().from(items).where(eq(items.id, id));
    return item || undefined;
  }

  async getItemBySku(sku: string): Promise<Item | undefined> {
    const [item] = await db.select().from(items).where(eq(items.sku, sku));
    return item || undefined;
  }

  async createItem(insertItem: InsertItem): Promise<Item> {
    const [item] = await db
      .insert(items)
      .values({
        ...insertItem,
        lastUpdated: new Date()
      })
      .returning();
    return item;
  }

  async updateItem(id: number, itemUpdate: Partial<InsertItem>): Promise<Item | undefined> {
    const [updatedItem] = await db
      .update(items)
      .set({
        ...itemUpdate,
        lastUpdated: new Date()
      })
      .where(eq(items.id, id))
      .returning();
    return updatedItem || undefined;
  }

  async deleteItem(id: number): Promise<boolean> {
    const result = await db
      .delete(items)
      .where(eq(items.id, id))
      .returning({ id: items.id });
    return result.length > 0;
  }

  async getLowStockItems(): Promise<ItemWithCategory[]> {
    const result = await db.execute(sql`
      SELECT 
        i.id, i.name, i.sku, i.description, i.price, i.quantity, 
        i.low_stock_threshold as "lowStockThreshold", 
        i.category_id as "categoryId", 
        i.last_updated as "lastUpdated",
        c.id as "cId", c.name as "cName", c.description as "cDescription"
      FROM ${items} i
      JOIN ${categories} c ON i.category_id = c.id
      WHERE i.quantity <= i.low_stock_threshold
    `);

    return result.rows.map(row => ({
      id: Number(row.id),
      name: String(row.name),
      sku: String(row.sku),
      description: row.description === null ? null : String(row.description),
      price: String(row.price),
      quantity: Number(row.quantity),
      lowStockThreshold: row.lowStockThreshold === null ? null : Number(row.lowStockThreshold),
      categoryId: Number(row.categoryId),
      lastUpdated: new Date(String(row.lastUpdated)),
      category: {
        id: Number(row.cId),
        name: String(row.cName),
        description: row.cDescription === null ? null : String(row.cDescription)
      }
    }));
  }

  async searchItems(query: string): Promise<ItemWithCategory[]> {
    const searchParam = `%${query.toLowerCase()}%`;
    const result = await db.execute(sql`
      SELECT 
        i.id, i.name, i.sku, i.description, i.price, i.quantity, 
        i.low_stock_threshold as "lowStockThreshold", 
        i.category_id as "categoryId", 
        i.last_updated as "lastUpdated",
        c.id as "cId", c.name as "cName", c.description as "cDescription"
      FROM ${items} i
      JOIN ${categories} c ON i.category_id = c.id
      WHERE LOWER(i.name) LIKE ${searchParam}
         OR LOWER(i.sku) LIKE ${searchParam}
         OR LOWER(c.name) LIKE ${searchParam}
    `);

    return result.rows.map(row => ({
      id: Number(row.id),
      name: String(row.name),
      sku: String(row.sku),
      description: row.description === null ? null : String(row.description),
      price: String(row.price),
      quantity: Number(row.quantity),
      lowStockThreshold: row.lowStockThreshold === null ? null : Number(row.lowStockThreshold),
      categoryId: Number(row.categoryId),
      lastUpdated: new Date(String(row.lastUpdated)),
      category: {
        id: Number(row.cId),
        name: String(row.cName),
        description: row.cDescription === null ? null : String(row.cDescription)
      }
    }));
  }

  async createTransaction(insertTransaction: InsertTransaction): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values({
        ...insertTransaction,
        createdAt: new Date()
      })
      .returning();

    // Update item quantity
    if (transaction.type === "stock_in") {
      await db
        .update(items)
        .set({
          quantity: sql`${items.quantity} + ${transaction.quantity}`,
          lastUpdated: new Date()
        })
        .where(eq(items.id, transaction.itemId));
    } else {
      await db
        .update(items)
        .set({
          quantity: sql`${items.quantity} - ${transaction.quantity}`,
          lastUpdated: new Date()
        })
        .where(eq(items.id, transaction.itemId));
    }

    return transaction;
  }

  async getTransactionsByItemId(itemId: number): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.itemId, itemId))
      .orderBy(desc(transactions.createdAt));
  }

  async getDashboardStats(): Promise<DashboardStats> {
    // Total items
    const [totalItemsResult] = await db.select({ count: sql`COUNT(*)` }).from(items);
    const totalItems = Number(totalItemsResult.count);

    // Low stock items
    const [lowStockItemsResult] = await db.select({ 
      count: sql`COUNT(*)`
    }).from(items).where(sql`${items.quantity} <= ${items.lowStockThreshold}`);
    const lowStockItems = Number(lowStockItemsResult.count);

    // Total categories
    const [categoriesResult] = await db.select({ count: sql`COUNT(*)` }).from(categories);
    const categoriesCount = Number(categoriesResult.count);

    // Total inventory value
    const [inventoryValueResult] = await db.select({ 
      total: sql`SUM(${items.price} * ${items.quantity})` 
    }).from(items);
    const totalValue = inventoryValueResult.total ? `$${Number(inventoryValueResult.total).toFixed(2)}` : "$0.00";

    // For now, return static growth data
    return {
      totalItems,
      itemsGrowth: "12% from last month",
      lowStockItems,
      lowStockGrowth: "5% from last week",
      categories: categoriesCount,
      categoriesGrowth: "2 new this month",
      totalValue,
      valueGrowth: "8% from last month"
    };
  }
}

export const storage = new DatabaseStorage();
