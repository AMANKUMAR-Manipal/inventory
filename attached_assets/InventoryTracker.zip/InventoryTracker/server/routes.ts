import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertCategorySchema, insertItemSchema, insertTransactionSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Categories API
  app.get("/api/categories", async (req: Request, res: Response) => {
    try {
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get("/api/categories/with-count", async (req: Request, res: Response) => {
    try {
      const categoriesWithCount = await storage.getCategoriesWithCount();
      res.json(categoriesWithCount);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories with count" });
    }
  });

  app.get("/api/categories/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }
      
      const category = await storage.getCategory(id);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch category" });
    }
  });

  app.post("/api/categories", async (req: Request, res: Response) => {
    try {
      const result = insertCategorySchema.safeParse(req.body);
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      // Check if category already exists
      const existingCategory = await storage.getCategoryByName(result.data.name);
      if (existingCategory) {
        return res.status(409).json({ message: "Category with this name already exists" });
      }
      
      const newCategory = await storage.createCategory(result.data);
      res.status(201).json(newCategory);
    } catch (error) {
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  app.put("/api/categories/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }
      
      const result = insertCategorySchema.partial().safeParse(req.body);
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      // Check if category exists
      const existingCategory = await storage.getCategory(id);
      if (!existingCategory) {
        return res.status(404).json({ message: "Category not found" });
      }
      
      // Check if name is being updated and already exists
      if (result.data.name && result.data.name !== existingCategory.name) {
        const categoryWithName = await storage.getCategoryByName(result.data.name);
        if (categoryWithName) {
          return res.status(409).json({ message: "Category with this name already exists" });
        }
      }
      
      const updatedCategory = await storage.updateCategory(id, result.data);
      res.json(updatedCategory);
    } catch (error) {
      res.status(500).json({ message: "Failed to update category" });
    }
  });

  app.delete("/api/categories/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid category ID" });
      }
      
      const success = await storage.deleteCategory(id);
      if (!success) {
        return res.status(400).json({ message: "Category cannot be deleted because it is in use" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete category" });
    }
  });

  // Items API
  app.get("/api/items", async (req: Request, res: Response) => {
    try {
      const query = req.query.q as string | undefined;
      let items;
      
      if (query) {
        items = await storage.searchItems(query);
      } else {
        items = await storage.getItemsWithCategories();
      }
      
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch items" });
    }
  });

  app.get("/api/items/low-stock", async (req: Request, res: Response) => {
    try {
      const lowStockItems = await storage.getLowStockItems();
      res.json(lowStockItems);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch low stock items" });
    }
  });

  app.get("/api/items/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid item ID" });
      }
      
      const item = await storage.getItem(id);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      res.json(item);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch item" });
    }
  });

  app.post("/api/items", async (req: Request, res: Response) => {
    try {
      const result = insertItemSchema.safeParse(req.body);
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      // Check if SKU already exists
      const existingItem = await storage.getItemBySku(result.data.sku);
      if (existingItem) {
        return res.status(409).json({ message: "Item with this SKU already exists" });
      }
      
      // Check if category exists
      const category = await storage.getCategory(result.data.categoryId);
      if (!category) {
        return res.status(400).json({ message: "Invalid category ID" });
      }
      
      const newItem = await storage.createItem(result.data);
      res.status(201).json(newItem);
    } catch (error) {
      res.status(500).json({ message: "Failed to create item" });
    }
  });

  app.put("/api/items/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid item ID" });
      }
      
      const result = insertItemSchema.partial().safeParse(req.body);
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      // Check if item exists
      const existingItem = await storage.getItem(id);
      if (!existingItem) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      // Check if SKU is being updated and already exists
      if (result.data.sku && result.data.sku !== existingItem.sku) {
        const itemWithSku = await storage.getItemBySku(result.data.sku);
        if (itemWithSku) {
          return res.status(409).json({ message: "Item with this SKU already exists" });
        }
      }
      
      // Check if category exists if it's being updated
      if (result.data.categoryId) {
        const category = await storage.getCategory(result.data.categoryId);
        if (!category) {
          return res.status(400).json({ message: "Invalid category ID" });
        }
      }
      
      const updatedItem = await storage.updateItem(id, result.data);
      res.json(updatedItem);
    } catch (error) {
      res.status(500).json({ message: "Failed to update item" });
    }
  });

  app.delete("/api/items/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid item ID" });
      }
      
      const success = await storage.deleteItem(id);
      if (!success) {
        return res.status(404).json({ message: "Item not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete item" });
    }
  });

  // Transactions API
  app.post("/api/transactions", async (req: Request, res: Response) => {
    try {
      const result = insertTransactionSchema.safeParse(req.body);
      if (!result.success) {
        const errorMessage = fromZodError(result.error).message;
        return res.status(400).json({ message: errorMessage });
      }
      
      // Check if item exists
      const item = await storage.getItem(result.data.itemId);
      if (!item) {
        return res.status(400).json({ message: "Invalid item ID" });
      }
      
      // Create transaction
      const transaction = await storage.createTransaction(result.data);
      
      // Update item quantity
      const newQuantity = result.data.type === 'in' 
        ? Number(item.quantity) + result.data.quantity
        : Number(item.quantity) - result.data.quantity;
      
      if (newQuantity < 0) {
        return res.status(400).json({ message: "Insufficient stock for this transaction" });
      }
      
      await storage.updateItem(item.id, { quantity: newQuantity });
      
      res.status(201).json(transaction);
    } catch (error) {
      res.status(500).json({ message: "Failed to create transaction" });
    }
  });

  app.get("/api/transactions/item/:itemId", async (req: Request, res: Response) => {
    try {
      const itemId = Number(req.params.itemId);
      if (isNaN(itemId)) {
        return res.status(400).json({ message: "Invalid item ID" });
      }
      
      const transactions = await storage.getTransactionsByItemId(itemId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Dashboard API
  app.get("/api/dashboard/stats", async (req: Request, res: Response) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  return httpServer;
}
