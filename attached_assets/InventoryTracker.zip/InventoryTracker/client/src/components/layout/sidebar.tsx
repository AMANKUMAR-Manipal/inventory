import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useSidebar } from "@/hooks/use-sidebar";
import { Header } from "./header";

type SidebarItem = {
  href: string;
  icon: string;
  label: string;
};

type SidebarSection = {
  title: string;
  items: SidebarItem[];
};

const sidebarSections: SidebarSection[] = [
  {
    title: "Main",
    items: [
      { href: "/", icon: "dashboard", label: "Dashboard" },
      { href: "/inventory", icon: "inventory_2", label: "Inventory" },
      { href: "/categories", icon: "category", label: "Categories" },
      { href: "/transactions", icon: "sync_alt", label: "Transactions" },
    ],
  },
  {
    title: "Reports",
    items: [
      { href: "/reports/stock", icon: "assessment", label: "Stock Levels" },
      { href: "/reports/performance", icon: "trending_up", label: "Performance" },
    ],
  },
  {
    title: "Settings",
    items: [
      { href: "/users", icon: "people", label: "Users" },
      { href: "/settings", icon: "settings", label: "Settings" },
    ],
  },
];

interface SidebarProps {
  isMobile?: boolean;
}

function Sidebar({ isMobile = false }: SidebarProps) {
  const [location] = useLocation();
  const { isOpen, toggleSidebar } = useSidebar();

  const sidebarStyles = cn(
    "bg-white dark:bg-gray-900 shadow-md w-64 fixed md:relative h-full z-20 transition-all duration-300 ease-in-out",
    isMobile && !isOpen && "-ml-64",
    !isMobile && !isOpen && "-ml-64",
    isMobile && isOpen && "ml-0",
    !isMobile && isOpen && "ml-0"
  );

  return (
    <aside className={sidebarStyles}>
      <nav className="p-4">
        {sidebarSections.map((section, index) => (
          <div key={index} className="mb-6">
            <p className="text-neutral-500 dark:text-neutral-400 text-xs uppercase font-medium px-3 mb-2">
              {section.title}
            </p>
            <ul>
              {section.items.map((item) => (
                <li key={item.href} className="mt-1 first:mt-0">
                  <Link
                    href={item.href}
                    onClick={() => isMobile && toggleSidebar()}
                    className={cn(
                      "flex items-center px-3 py-2 rounded-md hover:bg-neutral-100 dark:hover:bg-gray-800 relative",
                      location === item.href
                        ? "bg-primary/10 dark:bg-primary/20 text-primary font-medium border-l-4 border-primary pl-2"
                        : "text-neutral-700 dark:text-neutral-200"
                    )}
                  >
                    <span className="material-icons mr-3">{item.icon}</span>
                    <span>{item.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
}

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { isOpen } = useSidebar();
  const [isMobile, setIsMobile] = useState(false);

  // Check if mobile on mount and on resize
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    // Initial check
    checkIfMobile();

    // Add event listener
    window.addEventListener("resize", checkIfMobile);

    // Clean up
    return () => window.removeEventListener("resize", checkIfMobile);
  }, []);

  return (
    <div className="h-screen flex flex-col">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar isMobile={isMobile} />
        <main className={cn(
          "flex-1 overflow-auto bg-neutral-100 dark:bg-gray-800 p-6 transition-all duration-300",
          isMobile && isOpen && "opacity-50 md:opacity-100"
        )}>
          {children}
        </main>
      </div>
    </div>
  );
}
