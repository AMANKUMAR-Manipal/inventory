import { useState } from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useSidebar } from "@/hooks/use-sidebar";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useTheme } from "next-themes";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

export function Header() {
  const { toggleSidebar } = useSidebar();
  const [notificationCount] = useState(3);
  const { theme, setTheme } = useTheme();

  return (
    <header className="bg-primary text-white shadow-md z-10">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <Button
            variant="ghost"
            size="icon"
            className="mr-4 md:hidden text-white hover:bg-primary/20"
            onClick={toggleSidebar}
          >
            <span className="material-icons">menu</span>
          </Button>
          <h1 className="text-xl font-medium">Inventory Management System</h1>
        </div>
        <div className="flex items-center">
          <Popover>
            <PopoverTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="relative mr-2 text-white hover:bg-primary/20"
              >
                <span className="material-icons">notifications</span>
                {notificationCount > 0 && (
                  <span className="absolute top-1 right-1 bg-red-500 rounded-full w-4 h-4 flex items-center justify-center text-xs">
                    {notificationCount}
                  </span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 p-0">
              <div className="p-3 border-b border-neutral-200 dark:border-neutral-700">
                <h3 className="font-medium">Notifications</h3>
              </div>
              <div className="max-h-80 overflow-auto">
                <div className="p-3 border-b border-neutral-100 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-800">
                  <div className="flex items-start">
                    <div className="p-1 bg-red-100 dark:bg-red-900/30 text-red-500 dark:text-red-400 rounded mr-3">
                      <span className="material-icons text-sm">error</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Low stock alert</p>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400">HD Monitor is running low on stock</p>
                      <p className="text-xs text-neutral-400 dark:text-neutral-500 mt-1">2 hours ago</p>
                    </div>
                  </div>
                </div>
                <div className="p-3 border-b border-neutral-100 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-800">
                  <div className="flex items-start">
                    <div className="p-1 bg-amber-100 dark:bg-amber-900/30 text-amber-500 dark:text-amber-400 rounded mr-3">
                      <span className="material-icons text-sm">warning</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Low stock warning</p>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400">Ergonomic Chair is running low on stock</p>
                      <p className="text-xs text-neutral-400 dark:text-neutral-500 mt-1">5 hours ago</p>
                    </div>
                  </div>
                </div>
                <div className="p-3 hover:bg-neutral-50 dark:hover:bg-neutral-800">
                  <div className="flex items-start">
                    <div className="p-1 bg-green-100 dark:bg-green-900/30 text-green-500 dark:text-green-400 rounded mr-3">
                      <span className="material-icons text-sm">check_circle</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Stock update</p>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400">Wireless Keyboard stock has been updated</p>
                      <p className="text-xs text-neutral-400 dark:text-neutral-500 mt-1">1 day ago</p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-2 border-t border-neutral-200 dark:border-neutral-700">
                <Button variant="ghost" size="sm" className="w-full">
                  View all notifications
                </Button>
              </div>
            </PopoverContent>
          </Popover>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                className="flex items-center text-white hover:bg-primary/20"
              >
                <Avatar className="w-8 h-8 mr-2 bg-primary-light text-white">
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
                <span className="hidden md:block">John Doe</span>
                <span className="material-icons text-sm ml-1">arrow_drop_down</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <span className="material-icons mr-2 text-sm">person</span>
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem>
                <span className="material-icons mr-2 text-sm">settings</span>
                Settings
              </DropdownMenuItem>
              <div className="px-2 py-1.5 flex items-center justify-between">
                <div className="flex items-center">
                  <span className="material-icons mr-2 text-sm">
                    {theme === "dark" ? "dark_mode" : "light_mode"}
                  </span>
                  <span>Dark Mode</span>
                </div>
                <Switch
                  checked={theme === "dark"}
                  onCheckedChange={(checked) => setTheme(checked ? "dark" : "light")}
                />
              </div>
              <DropdownMenuItem>
                <span className="material-icons mr-2 text-sm">logout</span>
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
