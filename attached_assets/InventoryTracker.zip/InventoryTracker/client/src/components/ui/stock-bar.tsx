import { cn } from "@/lib/utils";

interface StockBarProps {
  quantity: number;
  threshold: number;
  max?: number;
  showText?: boolean;
  className?: string;
}

export function StockBar({ 
  quantity, 
  threshold, 
  max = 100, 
  showText = true, 
  className 
}: StockBarProps) {
  // Calculate percentage of stock
  const percentage = Math.min(Math.max((quantity / max) * 100, 0), 100);
  
  // Determine color based on threshold
  const getColorClass = () => {
    if (quantity <= threshold / 2) return "bg-red-500"; // Critical
    if (quantity <= threshold) return "bg-amber-500"; // Warning
    return "bg-emerald-600"; // Good
  };
  
  // Determine text color based on threshold
  const getTextColorClass = () => {
    if (quantity <= threshold / 2) return "text-red-500"; // Critical
    if (quantity <= threshold) return "text-amber-500"; // Warning
    return "text-neutral-700"; // Good
  };

  return (
    <div className={cn("flex items-center", className)}>
      <div className="w-16 bg-neutral-200 rounded-full h-2">
        <div 
          className={cn("h-2 rounded-full", getColorClass())}
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
      {showText && (
        <span className={cn("ml-2 text-sm", getTextColorClass())}>
          {quantity}
        </span>
      )}
    </div>
  );
}
