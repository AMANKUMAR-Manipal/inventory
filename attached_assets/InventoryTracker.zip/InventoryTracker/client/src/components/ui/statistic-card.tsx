import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatisticCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: {
    value: string;
    direction: "up" | "down";
  };
  className?: string;
}

export function StatisticCard({ title, value, icon, trend, className }: StatisticCardProps) {
  return (
    <Card className={cn("p-6", className)}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-neutral-600 text-sm">{title}</p>
          <h3 className="text-2xl font-medium text-neutral-800 mt-1">
            {value}
          </h3>
          {trend && (
            <p className={cn(
              "text-sm mt-2 flex items-center",
              trend.direction === "up" ? "text-green-600" : "text-red-600"
            )}>
              <span className="material-icons text-sm mr-1">
                {trend.direction === "up" ? "arrow_upward" : "arrow_downward"}
              </span>
              <span>{trend.value}</span>
            </p>
          )}
        </div>
        <div className="w-12 h-12 rounded-full flex items-center justify-center bg-opacity-10">
          {icon}
        </div>
      </div>
    </Card>
  );
}
