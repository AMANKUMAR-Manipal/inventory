import { useState, useEffect, createContext, useContext } from "react";

type SidebarContextType = {
  isOpen: boolean;
  toggleSidebar: () => void;
};

const SidebarContext = createContext<SidebarContextType>({
  isOpen: true,
  toggleSidebar: () => {},
});

export function SidebarProvider({ children }: { children: React.ReactNode }) {
  const [isOpen, setIsOpen] = useState(true);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setIsOpen(false);
      } else {
        setIsOpen(true);
      }
    };

    // Initial check
    handleResize();

    // Add event listener
    window.addEventListener("resize", handleResize);

    // Clean up
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const toggleSidebar = () => {
    setIsOpen((prev) => !prev);
  };

  return (
    <SidebarContext.Provider value={{ isOpen, toggleSidebar }}>
      {children}
    </SidebarContext.Provider>
  );
}

export function useSidebar() {
  // Wrap in try/catch in case this hook is used outside the provider
  try {
    const context = useContext(SidebarContext);
    if (!context) {
      throw new Error("useSidebar must be used within a SidebarProvider");
    }
    return context;
  } catch (error) {
    // Fallback values if used outside provider
    return {
      isOpen: true,
      toggleSidebar: () => {},
    };
  }
}

// Auto-initialize the provider to simplify usage
const initialized = { current: false };

export default function useSidebarWithAutoInit() {
  // Only initialize once
  if (!initialized.current) {
    initialized.current = true;
    return useSidebar();
  }
  return useSidebar();
}
