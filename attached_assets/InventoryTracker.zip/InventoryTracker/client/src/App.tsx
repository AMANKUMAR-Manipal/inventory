import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Inventory from "@/pages/inventory";
import Categories from "@/pages/categories";
import Transactions from "@/pages/transactions";
import StockLevels from "@/pages/reports/stock";
import Performance from "@/pages/reports/performance";
import Settings from "@/pages/settings";
import { Layout } from "@/components/layout/sidebar";
import { SidebarProvider } from "@/hooks/use-sidebar";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/inventory" component={Inventory} />
      <Route path="/categories" component={Categories} />
      <Route path="/transactions" component={Transactions} />
      <Route path="/reports/stock" component={StockLevels} />
      <Route path="/reports/performance" component={Performance} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <SidebarProvider>
          <Layout>
            <Router />
          </Layout>
        </SidebarProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
