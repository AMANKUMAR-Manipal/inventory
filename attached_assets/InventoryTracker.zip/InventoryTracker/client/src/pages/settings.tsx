import { useState, useEffect } from "react";
import { useTheme } from "next-themes";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Settings() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  // useEffect only runs on the client, so now we can safely show the UI
  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return null;
  }

  const saveDemoData = () => {
    toast({
      title: "Success",
      description: "Demo data has been loaded.",
    });
  };

  const clearData = () => {
    toast({
      title: "Database cleared",
      description: "All data has been reset to defaults.",
      variant: "destructive",
    });
  };

  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-medium text-neutral-800 dark:text-neutral-100">Settings</h2>
          <p className="text-neutral-600 dark:text-neutral-400 mt-1">Configure your inventory system</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Theme Settings */}
        <Card>
          <CardHeader>
            <CardTitle>Theme and Display</CardTitle>
            <CardDescription>Manage how your inventory system looks</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-medium">Dark Mode</h3>
                  <p className="text-sm text-muted-foreground">
                    Toggle between light and dark theme
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Label htmlFor="dark-mode" className="sr-only">
                    Dark Mode
                  </Label>
                  <Switch
                    id="dark-mode"
                    checked={theme === "dark"}
                    onCheckedChange={(checked) => setTheme(checked ? "dark" : "light")}
                  />
                </div>
              </div>

              <div className="flex flex-col space-y-2">
                <Label htmlFor="theme">Theme Color</Label>
                <Select
                  value={theme}
                  onValueChange={(value) => setTheme(value)}
                >
                  <SelectTrigger id="theme">
                    <SelectValue placeholder="Select a theme" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="system">System</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Data Management */}
        <Card>
          <CardHeader>
            <CardTitle>Data Management</CardTitle>
            <CardDescription>Control your inventory data</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex flex-col space-y-2">
                <Label htmlFor="demo-data">Demo Data</Label>
                <div className="flex items-center">
                  <Button 
                    onClick={saveDemoData}
                    className="mr-2"
                  >
                    Load Sample Data
                  </Button>
                  <Button 
                    variant="destructive"
                    onClick={clearData}
                  >
                    Clear All Data
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground">
                  Load sample data or clear your database
                </p>
              </div>

              <div className="flex flex-col space-y-2">
                <Label htmlFor="backup">Backup and Restore</Label>
                <div className="flex items-center">
                  <Button 
                    variant="outline"
                    className="mr-2"
                    onClick={() => toast({
                      title: "Backup created",
                      description: "Your data has been backed up."
                    })}
                  >
                    Backup Data
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => toast({
                      title: "Not implemented",
                      description: "This feature is not yet available.",
                      variant: "destructive"
                    })}
                  >
                    Restore Data
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* User Preferences */}
        <Card>
          <CardHeader>
            <CardTitle>User Preferences</CardTitle>
            <CardDescription>Customize your experience</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-medium">Show Low Stock Alerts</h3>
                  <p className="text-sm text-muted-foreground">
                    Display notifications for low stock items
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="alerts"
                    defaultChecked={true}
                    onCheckedChange={(checked) => {
                      toast({
                        title: checked ? "Alerts enabled" : "Alerts disabled",
                        description: checked 
                          ? "You will now receive low stock alerts." 
                          : "You will no longer receive low stock alerts."
                      });
                    }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-medium">Auto-refresh Dashboard</h3>
                  <p className="text-sm text-muted-foreground">
                    Automatically update dashboard data
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="auto-refresh"
                    defaultChecked={false}
                    onCheckedChange={(checked) => {
                      toast({
                        title: checked ? "Auto-refresh enabled" : "Auto-refresh disabled",
                        description: checked 
                          ? "Dashboard will refresh automatically." 
                          : "Dashboard will refresh manually."
                      });
                    }}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* System Info */}
        <Card>
          <CardHeader>
            <CardTitle>System Information</CardTitle>
            <CardDescription>Details about your inventory system</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div className="flex flex-col">
                <h3 className="text-sm font-medium">Version</h3>
                <p className="text-sm text-muted-foreground">1.0.0</p>
              </div>

              <div className="flex flex-col">
                <h3 className="text-sm font-medium">Database</h3>
                <p className="text-sm text-muted-foreground">PostgreSQL</p>
              </div>

              <div className="flex flex-col">
                <h3 className="text-sm font-medium">Last Updated</h3>
                <p className="text-sm text-muted-foreground">{new Date().toLocaleDateString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}