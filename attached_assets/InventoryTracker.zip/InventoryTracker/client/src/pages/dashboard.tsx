import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { DashboardStats, ItemWithCategory, CategoryWithCount, Item } from "@shared/schema";
import { StatisticCard } from "@/components/ui/statistic-card";
import { StockBar } from "@/components/ui/stock-bar";
import { AddItemDialog } from "@/components/dialogs/add-item-dialog";
import { EditItemDialog } from "@/components/dialogs/edit-item-dialog";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const [isAddItemDialogOpen, setIsAddItemDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [itemToEdit, setItemToEdit] = useState<Item | null>(null);

  // Fetch dashboard stats
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  // Fetch items with categories
  const { data: items, isLoading: itemsLoading } = useQuery<ItemWithCategory[]>({
    queryKey: ["/api/items"],
  });

  // Fetch low stock items
  const { data: lowStockItems, isLoading: lowStockLoading } = useQuery<ItemWithCategory[]>({
    queryKey: ["/api/items/low-stock"],
  });

  // Fetch categories with counts
  const { data: categoriesWithCount, isLoading: categoriesLoading } = useQuery<CategoryWithCount[]>({
    queryKey: ["/api/categories/with-count"],
  });

  // Search functionality
  const filteredItems = items?.filter(item =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.category.name.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  // Renders loading stat card placeholder
  const renderStatCardSkeleton = () => (
    <Card className="p-6">
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <Skeleton className="h-4 w-24" />
          <Skeleton className="h-8 w-32 mt-1" />
          <Skeleton className="h-4 w-36 mt-2" />
        </div>
        <Skeleton className="h-12 w-12 rounded-full" />
      </div>
    </Card>
  );

  const renderItemsSkeleton = () => (
    <TableRow>
      <TableCell colSpan={6}>
        <div className="flex justify-center p-4">
          <Skeleton className="h-8 w-full max-w-lg" />
        </div>
      </TableCell>
    </TableRow>
  );

  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-medium text-neutral-800">Dashboard</h2>
          <p className="text-neutral-600 mt-1">Overview of your inventory system</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button 
            className="flex items-center shadow-sm"
            onClick={() => setIsAddItemDialogOpen(true)}
          >
            <span className="material-icons mr-1 text-sm">add</span>
            Add Item
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        {statsLoading ? (
          <>
            {renderStatCardSkeleton()}
            {renderStatCardSkeleton()}
            {renderStatCardSkeleton()}
            {renderStatCardSkeleton()}
          </>
        ) : (
          <>
            <StatisticCard
              title="Total Items"
              value={stats?.totalItems || 0}
              icon={<span className="material-icons text-primary">inventory_2</span>}
              trend={{
                value: stats?.itemsGrowth || "0% from last month",
                direction: "up"
              }}
              className="bg-primary/10"
            />
            <StatisticCard
              title="Low Stock Items"
              value={stats?.lowStockItems || 0}
              icon={<span className="material-icons text-warning-500">warning</span>}
              trend={{
                value: stats?.lowStockGrowth || "0% from last week",
                direction: "up"
              }}
              className="bg-warning-500/10"
            />
            <StatisticCard
              title="Categories"
              value={stats?.categories || 0}
              icon={<span className="material-icons text-info">category</span>}
              trend={{
                value: stats?.categoriesGrowth || "0 new this month",
                direction: "up"
              }}
              className="bg-info/10"
            />
            <StatisticCard
              title="Total Value"
              value={stats?.totalValue || "$0"}
              icon={<span className="material-icons text-secondary">attach_money</span>}
              trend={{
                value: stats?.valueGrowth || "0% from last month",
                direction: "up"
              }}
              className="bg-secondary/10"
            />
          </>
        )}
      </div>

      {/* Recent Items Section */}
      <Card className="mb-6">
        <CardHeader className="border-b border-neutral-200">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <CardTitle className="text-lg font-medium">Recent Items</CardTitle>
            <div className="flex mt-2 md:mt-0">
              <div className="relative mr-4">
                <span className="material-icons text-neutral-400 absolute left-3 top-2">
                  search
                </span>
                <Input
                  type="text"
                  placeholder="Search items..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button variant="outline" size="icon">
                <span className="material-icons">filter_list</span>
              </Button>
            </div>
          </div>
        </CardHeader>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-neutral-50">
              <TableRow>
                <TableHead className="whitespace-nowrap">
                  <div className="flex items-center cursor-pointer">
                    Item Name
                    <span className="material-icons text-sm ml-1">arrow_downward</span>
                  </div>
                </TableHead>
                <TableHead className="whitespace-nowrap">Category</TableHead>
                <TableHead className="whitespace-nowrap">
                  <div className="flex items-center cursor-pointer">Stock</div>
                </TableHead>
                <TableHead className="whitespace-nowrap">Unit Price</TableHead>
                <TableHead className="whitespace-nowrap">Last Updated</TableHead>
                <TableHead className="text-right whitespace-nowrap">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {itemsLoading ? (
                Array(5).fill(0).map((_, index) => (
                  <TableRow key={`skeleton-${index}`}>
                    <TableCell colSpan={6}>
                      <Skeleton className="h-8 w-full max-w-lg" />
                    </TableCell>
                  </TableRow>
                ))
              ) : filteredItems.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-neutral-500">
                    {searchQuery ? "No items found matching your search." : "No items available."}
                  </TableCell>
                </TableRow>
              ) : (
                filteredItems.slice(0, 5).map((item) => (
                  <TableRow key={item.id} className="hover:bg-neutral-50">
                    <TableCell className="whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-10 w-10 bg-neutral-200 rounded-md flex items-center justify-center">
                          <span className="material-icons text-neutral-600">inventory</span>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-neutral-900">{item.name}</div>
                          <div className="text-sm text-neutral-500">{item.sku}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge variant="outline" className="bg-primary bg-opacity-10 text-primary border-primary/20">
                        {item.category.name}
                      </Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      <StockBar 
                        quantity={Number(item.quantity)} 
                        threshold={Number(item.lowStockThreshold)}
                        max={Number(item.lowStockThreshold) * 5}
                      />
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-neutral-700">
                      ${Number(item.price).toFixed(2)}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-neutral-500">
                      {new Date(item.lastUpdated).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-right text-sm font-medium">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-primary hover:text-primary/80"
                        onClick={() => setItemToEdit(item)}
                      >
                        <span className="material-icons">edit</span>
                      </Button>
                      <Button variant="ghost" size="icon" className="text-neutral-600 hover:text-neutral-800">
                        <span className="material-icons">more_vert</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        <div className="px-6 py-3 flex items-center justify-between border-t border-neutral-200">
          <div className="flex items-center">
            <span className="text-sm text-neutral-700">
              Showing <span className="font-medium">1</span> to{" "}
              <span className="font-medium">{Math.min(filteredItems.length, 5)}</span> of{" "}
              <span className="font-medium">{filteredItems.length}</span> results
            </span>
          </div>
          <div className="flex items-center">
            <Button 
              variant="outline" 
              size="icon" 
              className="rounded-l-md rounded-r-none border-r-0" 
              disabled
            >
              <span className="material-icons text-sm">chevron_left</span>
            </Button>
            <Button 
              variant="outline" 
              className="rounded-none border-x-0 bg-primary text-white"
            >
              1
            </Button>
            <Button variant="outline" className="rounded-none border-x-0">
              2
            </Button>
            <Button variant="outline" className="rounded-none border-l-0 border-r-0">
              3
            </Button>
            <Button variant="outline" className="rounded-l-none rounded-r-md border-l-0">
              <span className="material-icons text-sm">chevron_right</span>
            </Button>
          </div>
        </div>
      </Card>

      {/* Low Stock Alert and Category Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Low Stock Alert Section */}
        <Card>
          <CardHeader className="border-b border-neutral-200">
            <CardTitle className="text-lg font-medium">Low Stock Alerts</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {lowStockLoading ? (
              <div className="space-y-4">
                {Array(3).fill(0).map((_, idx) => (
                  <Skeleton key={idx} className="h-16 w-full" />
                ))}
              </div>
            ) : lowStockItems?.length === 0 ? (
              <div className="text-center py-6 text-neutral-500">
                No low stock items. Everything is well stocked!
              </div>
            ) : (
              <div className="space-y-4">
                {lowStockItems?.map((item) => (
                  <div 
                    key={item.id} 
                    className={`flex items-center p-3 rounded-md border-l-4 ${
                      Number(item.quantity) <= Number(item.lowStockThreshold) / 2
                        ? "bg-red-50 border-red-500"
                        : "bg-amber-50 border-amber-500"
                    }`}
                  >
                    <span 
                      className={`material-icons mr-3 ${
                        Number(item.quantity) <= Number(item.lowStockThreshold) / 2
                          ? "text-red-500"
                          : "text-amber-500"
                      }`}
                    >
                      {Number(item.quantity) <= Number(item.lowStockThreshold) / 2 ? "error" : "warning"}
                    </span>
                    <div>
                      <p className="text-sm font-medium text-neutral-800">{item.name}</p>
                      <p className="text-xs text-neutral-600">Only {item.quantity} left in stock</p>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className={`ml-auto ${
                        Number(item.quantity) <= Number(item.lowStockThreshold) / 2
                          ? "text-red-500 border-red-500 hover:bg-red-500 hover:text-white"
                          : "text-amber-500 border-amber-500 hover:bg-amber-500 hover:text-white"
                      }`}
                    >
                      Reorder
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Category Distribution Section */}
        <Card>
          <CardHeader className="border-b border-neutral-200">
            <CardTitle className="text-lg font-medium">Category Distribution</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {categoriesLoading ? (
              <div className="space-y-4">
                {Array(4).fill(0).map((_, idx) => (
                  <div key={idx} className="space-y-2">
                    <div className="flex justify-between">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-4 w-12" />
                    </div>
                    <Skeleton className="h-2.5 w-full" />
                  </div>
                ))}
              </div>
            ) : categoriesWithCount?.length === 0 ? (
              <div className="text-center py-6 text-neutral-500">
                No categories available.
              </div>
            ) : (
              <div className="space-y-4">
                {categoriesWithCount?.map((category, index) => {
                  // Assign different colors based on index
                  const colors = ["bg-primary", "bg-info", "bg-secondary", "bg-warning-500"];
                  const color = colors[index % colors.length];
                  
                  return (
                    <div key={category.id}>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium text-neutral-700">{category.name}</span>
                        <span className="text-sm text-neutral-700">{category.percentage}%</span>
                      </div>
                      <div className="w-full bg-neutral-200 rounded-full h-2.5">
                        <div 
                          className={`${color} h-2.5 rounded-full`} 
                          style={{ width: `${category.percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Add Item Dialog */}
      <AddItemDialog
        open={isAddItemDialogOpen}
        onOpenChange={setIsAddItemDialogOpen}
      />

      {/* Edit Item Dialog */}
      <EditItemDialog
        open={!!itemToEdit}
        onOpenChange={(open) => !open && setItemToEdit(null)}
        item={itemToEdit}
      />
    </>
  );
}
