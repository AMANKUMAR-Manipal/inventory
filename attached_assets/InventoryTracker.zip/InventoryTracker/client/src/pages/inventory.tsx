import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ItemWithCategory, Item } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { StockBar } from "@/components/ui/stock-bar";
import { AddItemDialog } from "@/components/dialogs/add-item-dialog";
import { EditItemDialog } from "@/components/dialogs/edit-item-dialog";
import { useToast } from "@/hooks/use-toast";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";

export default function Inventory() {
  const [isAddItemDialogOpen, setIsAddItemDialogOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [itemToDelete, setItemToDelete] = useState<ItemWithCategory | null>(null);
  const [itemToEdit, setItemToEdit] = useState<Item | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch items with categories
  const { data: items, isLoading } = useQuery<ItemWithCategory[]>({
    queryKey: ["/api/items"],
  });

  // Delete item mutation
  const deleteItemMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/items/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/items/low-stock"] });
      toast({
        title: "Success",
        description: "Item successfully deleted.",
      });
      setItemToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete item. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Search functionality
  const filteredItems = items?.filter(item =>
    item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.category.name.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  // Loading skeleton
  const renderItemsSkeleton = () => (
    <>
      {Array(5).fill(0).map((_, index) => (
        <TableRow key={index}>
          <TableCell colSpan={6}>
            <div className="flex justify-center p-4">
              <Skeleton className="h-8 w-full max-w-lg" />
            </div>
          </TableCell>
        </TableRow>
      ))}
    </>
  );

  const handleDeleteItem = () => {
    if (itemToDelete) {
      deleteItemMutation.mutate(itemToDelete.id);
    }
  };

  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-medium text-neutral-800">Inventory</h2>
          <p className="text-neutral-600 mt-1">Manage your inventory items</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button 
            className="flex items-center shadow-sm"
            onClick={() => setIsAddItemDialogOpen(true)}
          >
            <span className="material-icons mr-1 text-sm">add</span>
            Add Item
          </Button>
        </div>
      </div>

      {/* Items Table */}
      <Card>
        <CardHeader className="border-b border-neutral-200">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <CardTitle className="text-lg font-medium">All Items</CardTitle>
            <div className="flex mt-2 md:mt-0">
              <div className="relative mr-4">
                <span className="material-icons text-neutral-400 absolute left-3 top-2">
                  search
                </span>
                <Input
                  type="text"
                  placeholder="Search items..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button variant="outline" size="icon">
                <span className="material-icons">filter_list</span>
              </Button>
            </div>
          </div>
        </CardHeader>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-neutral-50">
              <TableRow>
                <TableHead className="whitespace-nowrap">
                  <div className="flex items-center cursor-pointer">
                    Item Name
                    <span className="material-icons text-sm ml-1">arrow_downward</span>
                  </div>
                </TableHead>
                <TableHead className="whitespace-nowrap">Category</TableHead>
                <TableHead className="whitespace-nowrap">
                  <div className="flex items-center cursor-pointer">Stock</div>
                </TableHead>
                <TableHead className="whitespace-nowrap">Unit Price</TableHead>
                <TableHead className="whitespace-nowrap">Last Updated</TableHead>
                <TableHead className="text-right whitespace-nowrap">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                renderItemsSkeleton()
              ) : filteredItems.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-neutral-500">
                    {searchQuery ? "No items found matching your search." : "No items available."}
                  </TableCell>
                </TableRow>
              ) : (
                filteredItems.map((item) => (
                  <TableRow key={item.id} className="hover:bg-neutral-50">
                    <TableCell className="whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-10 w-10 bg-neutral-200 rounded-md flex items-center justify-center">
                          <span className="material-icons text-neutral-600">inventory</span>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-neutral-900">{item.name}</div>
                          <div className="text-sm text-neutral-500">{item.sku}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      <Badge variant="outline" className="bg-primary bg-opacity-10 text-primary border-primary/20">
                        {item.category.name}
                      </Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      <StockBar 
                        quantity={Number(item.quantity)} 
                        threshold={Number(item.lowStockThreshold)}
                        max={Number(item.lowStockThreshold) * 5}
                      />
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-neutral-700">
                      ${Number(item.price).toFixed(2)}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm text-neutral-500">
                      {new Date(item.lastUpdated).toLocaleDateString()}
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-right text-sm font-medium">
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-primary hover:text-primary/80"
                        onClick={() => setItemToEdit(item)}
                      >
                        <span className="material-icons">edit</span>
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="text-neutral-600 hover:text-red-500"
                        onClick={() => setItemToDelete(item)}
                      >
                        <span className="material-icons">delete</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        <div className="px-6 py-3 flex items-center justify-between border-t border-neutral-200">
          <div className="flex items-center">
            <span className="text-sm text-neutral-700">
              Showing{" "}
              <span className="font-medium">
                {filteredItems.length > 0 ? 1 : 0}
              </span>{" "}
              to{" "}
              <span className="font-medium">
                {filteredItems.length}
              </span>{" "}
              of{" "}
              <span className="font-medium">
                {filteredItems.length}
              </span>{" "}
              results
            </span>
          </div>
          <div className="flex items-center">
            <Button 
              variant="outline" 
              size="icon" 
              className="rounded-l-md rounded-r-none border-r-0" 
              disabled
            >
              <span className="material-icons text-sm">chevron_left</span>
            </Button>
            <Button 
              variant="outline" 
              className="rounded-none border-x-0 bg-primary text-white"
            >
              1
            </Button>
            <Button 
              variant="outline" 
              size="icon" 
              className="rounded-l-none rounded-r-md border-l-0"
              disabled
            >
              <span className="material-icons text-sm">chevron_right</span>
            </Button>
          </div>
        </div>
      </Card>

      {/* Add Item Dialog */}
      <AddItemDialog
        open={isAddItemDialogOpen}
        onOpenChange={setIsAddItemDialogOpen}
      />

      {/* Edit Item Dialog */}
      <EditItemDialog
        open={!!itemToEdit}
        onOpenChange={(open) => !open && setItemToEdit(null)}
        item={itemToEdit}
      />

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!itemToDelete} onOpenChange={(open) => !open && setItemToDelete(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Item</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{itemToDelete?.name}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setItemToDelete(null)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeleteItem}
              disabled={deleteItemMutation.isPending}
            >
              {deleteItemMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
