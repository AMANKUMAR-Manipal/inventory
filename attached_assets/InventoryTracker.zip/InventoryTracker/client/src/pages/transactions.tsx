import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Transaction } from "@shared/schema";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

export default function Transactions() {
  const [searchQuery, setSearchQuery] = useState("");

  // Placeholder for transaction data until we implement proper API calls
  const mockTransactions = [
    {
      id: 1,
      itemId: 1,
      type: "in",
      quantity: 50,
      date: "2023-05-15T10:30:00Z",
      notes: "Initial stock",
      createdAt: "2023-05-15T10:30:00Z",
      itemName: "Wireless Keyboard"
    },
    {
      id: 2,
      itemId: 1,
      type: "out",
      quantity: 5,
      date: "2023-05-18T14:45:00Z",
      notes: "Sales order #12345",
      createdAt: "2023-05-18T14:45:00Z",
      itemName: "Wireless Keyboard"
    },
    {
      id: 3,
      itemId: 2,
      type: "in",
      quantity: 25,
      date: "2023-05-20T09:15:00Z",
      notes: "Restocking",
      createdAt: "2023-05-20T09:15:00Z",
      itemName: "Ergonomic Mouse"
    },
  ];

  // Simulate loading state
  const isLoading = false;
  const transactions = mockTransactions;

  // Search functionality
  const filteredTransactions = transactions?.filter(transaction =>
    transaction.itemName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    transaction.notes?.toLowerCase().includes(searchQuery.toLowerCase())
  ) || [];

  // Helper function to format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-medium text-neutral-800">Transactions</h2>
          <p className="text-neutral-600 mt-1">Track inventory movements</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button 
            className="flex items-center shadow-sm"
          >
            <span className="material-icons mr-1 text-sm">add</span>
            New Transaction
          </Button>
        </div>
      </div>

      {/* Transactions Table */}
      <Card>
        <CardHeader className="border-b border-neutral-200">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <CardTitle className="text-lg font-medium">Transaction History</CardTitle>
            <div className="flex mt-2 md:mt-0">
              <div className="relative mr-4">
                <span className="material-icons text-neutral-400 absolute left-3 top-2">
                  search
                </span>
                <Input
                  type="text"
                  placeholder="Search transactions..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button variant="outline" size="icon">
                <span className="material-icons">filter_list</span>
              </Button>
            </div>
          </div>
        </CardHeader>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-neutral-50">
              <TableRow>
                <TableHead className="whitespace-nowrap">Date & Time</TableHead>
                <TableHead className="whitespace-nowrap">Item</TableHead>
                <TableHead className="whitespace-nowrap">Type</TableHead>
                <TableHead className="whitespace-nowrap">Quantity</TableHead>
                <TableHead className="whitespace-nowrap">Notes</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array(5).fill(0).map((_, index) => (
                  <TableRow key={index}>
                    <TableCell colSpan={5}>
                      <Skeleton className="h-8 w-full" />
                    </TableCell>
                  </TableRow>
                ))
              ) : filteredTransactions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-neutral-500">
                    {searchQuery ? "No transactions found matching your search." : "No transactions available."}
                  </TableCell>
                </TableRow>
              ) : (
                filteredTransactions.map((transaction) => (
                  <TableRow key={transaction.id} className="hover:bg-neutral-50">
                    <TableCell className="whitespace-nowrap">
                      {formatDate(transaction.date)}
                    </TableCell>
                    <TableCell>{transaction.itemName}</TableCell>
                    <TableCell>
                      <Badge variant={transaction.type === 'in' ? 'default' : 'destructive'} className={transaction.type === 'in' ? 'bg-emerald-500' : ''}>
                        {transaction.type === 'in' ? 'Stock In' : 'Stock Out'}
                      </Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {transaction.quantity}
                    </TableCell>
                    <TableCell className="max-w-md truncate">
                      {transaction.notes}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </>
  );
}