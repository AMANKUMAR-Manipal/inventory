import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { DashboardStats, ItemWithCategory, CategoryWithCount } from "@shared/schema";

import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { StatisticCard } from "@/components/ui/statistic-card";

export default function Performance() {
  // Date range for filtering (placeholder for future implementation)
  const [dateRange, setDateRange] = useState({
    start: new Date(new Date().setMonth(new Date().getMonth() - 1)), // Last month
    end: new Date()
  });

  // Fetch dashboard stats
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  // Fetch categories with counts
  const { data: categoriesWithCount, isLoading: categoriesLoading } = useQuery<CategoryWithCount[]>({
    queryKey: ["/api/categories/with-count"],
  });

  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-medium text-neutral-800">Performance Report</h2>
          <p className="text-neutral-600 mt-1">Overview of inventory performance metrics</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button 
            variant="outline"
            className="flex items-center shadow-sm mr-2"
          >
            <span className="material-icons mr-1 text-sm">print</span>
            Print Report
          </Button>
          <Button 
            className="flex items-center shadow-sm"
          >
            <span className="material-icons mr-1 text-sm">download</span>
            Export
          </Button>
        </div>
      </div>

      {/* Performance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        {statsLoading ? (
          <>
            <Skeleton className="h-[120px] w-full" />
            <Skeleton className="h-[120px] w-full" />
            <Skeleton className="h-[120px] w-full" />
            <Skeleton className="h-[120px] w-full" />
          </>
        ) : (
          <>
            <StatisticCard
              title="Total Items"
              value={stats?.totalItems || 0}
              icon={<span className="material-icons text-primary">inventory_2</span>}
              trend={{
                value: stats?.itemsGrowth || "0% from last month",
                direction: "up"
              }}
              className="bg-primary/10"
            />
            <StatisticCard
              title="Low Stock Items"
              value={stats?.lowStockItems || 0}
              icon={<span className="material-icons text-warning-500">warning</span>}
              trend={{
                value: stats?.lowStockGrowth || "0% from last week",
                direction: "up"
              }}
              className="bg-warning-500/10"
            />
            <StatisticCard
              title="Categories"
              value={stats?.categories || 0}
              icon={<span className="material-icons text-info">category</span>}
              trend={{
                value: stats?.categoriesGrowth || "0 new this month",
                direction: "up"
              }}
              className="bg-info/10"
            />
            <StatisticCard
              title="Total Value"
              value={stats?.totalValue || "$0"}
              icon={<span className="material-icons text-secondary">attach_money</span>}
              trend={{
                value: stats?.valueGrowth || "0% from last month",
                direction: "up"
              }}
              className="bg-secondary/10"
            />
          </>
        )}
      </div>

      {/* Category Distribution */}
      <Card className="mb-6">
        <CardHeader className="border-b border-neutral-200">
          <CardTitle className="text-lg font-medium">Category Distribution</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          {categoriesLoading ? (
            <div className="space-y-4">
              {Array(4).fill(0).map((_, idx) => (
                <div key={idx} className="space-y-2">
                  <div className="flex justify-between">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-12" />
                  </div>
                  <Skeleton className="h-2.5 w-full" />
                </div>
              ))}
            </div>
          ) : categoriesWithCount?.length === 0 ? (
            <div className="text-center py-6 text-neutral-500">
              No categories available.
            </div>
          ) : (
            <div className="space-y-4">
              {categoriesWithCount?.map((category, index) => {
                // Assign different colors based on index
                const colors = ["bg-primary", "bg-info", "bg-secondary", "bg-warning-500"];
                const color = colors[index % colors.length];
                
                return (
                  <div key={category.id}>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-neutral-700">{category.name}</span>
                      <span className="text-sm text-neutral-700">{category.percentage}%</span>
                    </div>
                    <div className="w-full bg-neutral-200 rounded-full h-2.5">
                      <div 
                        className={`${color} h-2.5 rounded-full`}
                        style={{ width: `${category.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Value Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="border-b border-neutral-200">
            <CardTitle className="text-lg font-medium">Top Items by Value</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="text-center py-6 text-neutral-500">
              <span className="material-icons text-4xl text-neutral-300 mb-2">
                analytics
              </span>
              <p>Detailed value analytics will be available in a future update.</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="border-b border-neutral-200">
            <CardTitle className="text-lg font-medium">Stock Turn Rate</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="text-center py-6 text-neutral-500">
              <span className="material-icons text-4xl text-neutral-300 mb-2">
                trending_up
              </span>
              <p>Stock turnover analytics will be available in a future update.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}