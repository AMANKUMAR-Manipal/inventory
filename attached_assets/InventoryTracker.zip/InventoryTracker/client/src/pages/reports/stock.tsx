import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ItemWithCategory } from "@shared/schema";
import { StockBar } from "@/components/ui/stock-bar";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";

export default function StockLevels() {
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("name"); // name, quantity, category
  const [sortOrder, setSortOrder] = useState("asc"); // asc, desc

  // Fetch items with categories
  const { data: items, isLoading } = useQuery<ItemWithCategory[]>({
    queryKey: ["/api/items"],
  });

  // Sorting and filtering functionality
  const sortedAndFilteredItems = items
    ?.filter(item =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.name.toLowerCase().includes(searchQuery.toLowerCase())
    )
    .sort((a, b) => {
      if (sortBy === "name") {
        return sortOrder === "asc" 
          ? a.name.localeCompare(b.name)
          : b.name.localeCompare(a.name);
      } else if (sortBy === "quantity") {
        return sortOrder === "asc" 
          ? Number(a.quantity) - Number(b.quantity)
          : Number(b.quantity) - Number(a.quantity);
      } else if (sortBy === "category") {
        return sortOrder === "asc" 
          ? a.category.name.localeCompare(b.category.name)
          : b.category.name.localeCompare(a.category.name);
      }
      return 0;
    }) || [];

  // Helper function to get stock status
  const getStockStatus = (item: ItemWithCategory) => {
    const quantity = Number(item.quantity);
    const threshold = Number(item.lowStockThreshold);
    
    if (quantity <= threshold / 2) {
      return { label: "Critical", color: "bg-red-100 text-red-500" };
    } else if (quantity <= threshold) {
      return { label: "Low", color: "bg-amber-100 text-amber-500" };
    } else if (quantity <= threshold * 2) {
      return { label: "Adequate", color: "bg-blue-100 text-blue-500" };
    } else {
      return { label: "Good", color: "bg-emerald-100 text-emerald-500" };
    }
  };

  // Toggle sort order
  const toggleSort = (field: string) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(field);
      setSortOrder("asc");
    }
  };

  // Render sort indicator
  const renderSortIndicator = (field: string) => {
    if (sortBy !== field) return null;
    
    return (
      <span className="material-icons text-sm ml-1">
        {sortOrder === "asc" ? "arrow_upward" : "arrow_downward"}
      </span>
    );
  };

  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-medium text-neutral-800">Stock Levels</h2>
          <p className="text-neutral-600 mt-1">Monitor inventory stock levels</p>
        </div>
        <div className="mt-4 md:mt-0">
          <Button 
            variant="outline"
            className="flex items-center shadow-sm mr-2"
          >
            <span className="material-icons mr-1 text-sm">print</span>
            Print Report
          </Button>
          <Button 
            className="flex items-center shadow-sm"
          >
            <span className="material-icons mr-1 text-sm">download</span>
            Export
          </Button>
        </div>
      </div>

      {/* Stock Levels Table */}
      <Card>
        <CardHeader className="border-b border-neutral-200">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <CardTitle className="text-lg font-medium">Stock Level Report</CardTitle>
            <div className="flex mt-2 md:mt-0">
              <div className="relative mr-4">
                <span className="material-icons text-neutral-400 absolute left-3 top-2">
                  search
                </span>
                <Input
                  type="text"
                  placeholder="Search items..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button variant="outline" size="icon">
                <span className="material-icons">filter_list</span>
              </Button>
            </div>
          </div>
        </CardHeader>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-neutral-50">
              <TableRow>
                <TableHead className="whitespace-nowrap">
                  <div className="flex items-center cursor-pointer" onClick={() => toggleSort("name")}>
                    Item Name
                    {renderSortIndicator("name")}
                  </div>
                </TableHead>
                <TableHead className="whitespace-nowrap">
                  <div className="flex items-center cursor-pointer" onClick={() => toggleSort("category")}>
                    Category
                    {renderSortIndicator("category")}
                  </div>
                </TableHead>
                <TableHead className="whitespace-nowrap">
                  <div className="flex items-center cursor-pointer" onClick={() => toggleSort("quantity")}>
                    Stock Level
                    {renderSortIndicator("quantity")}
                  </div>
                </TableHead>
                <TableHead className="whitespace-nowrap">Status</TableHead>
                <TableHead className="whitespace-nowrap">Threshold</TableHead>
                <TableHead className="whitespace-nowrap">Value</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array(5).fill(0).map((_, index) => (
                  <TableRow key={index}>
                    <TableCell colSpan={6}>
                      <Skeleton className="h-8 w-full" />
                    </TableCell>
                  </TableRow>
                ))
              ) : sortedAndFilteredItems.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-neutral-500">
                    {searchQuery ? "No items found matching your search." : "No items available."}
                  </TableCell>
                </TableRow>
              ) : (
                sortedAndFilteredItems.map((item) => {
                  const stockStatus = getStockStatus(item);
                  
                  return (
                    <TableRow key={item.id} className="hover:bg-neutral-50">
                      <TableCell className="whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-10 w-10 bg-neutral-200 rounded-md flex items-center justify-center">
                            <span className="material-icons text-neutral-600">inventory</span>
                          </div>
                          <div className="ml-4">
                            <div className="text-sm font-medium text-neutral-900">{item.name}</div>
                            <div className="text-sm text-neutral-500">{item.sku}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <Badge variant="outline" className="bg-primary bg-opacity-10 text-primary border-primary/20">
                          {item.category.name}
                        </Badge>
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <StockBar 
                          quantity={Number(item.quantity)} 
                          threshold={Number(item.lowStockThreshold)}
                          max={Number(item.lowStockThreshold) * 5}
                        />
                      </TableCell>
                      <TableCell className="whitespace-nowrap">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${stockStatus.color}`}>
                          {stockStatus.label}
                        </span>
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-neutral-700">
                        {item.lowStockThreshold}
                      </TableCell>
                      <TableCell className="whitespace-nowrap text-sm text-neutral-700">
                        ${(Number(item.price) * Number(item.quantity)).toFixed(2)}
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </Card>
    </>
  );
}